# Qulaycafe — Multi-Tenant Upgrade

This turns Qulaycafe from a single-restaurant app into a system where many
restaurants can each run their own menu/orders/tables/staff under one
deployment, with you (Alex) managing subscriptions by hand through a private
Telegram bot — no payment gateway involved.

## What changed

- **Database**: every table (menu, orders, tables, loyalty, staff accounts,
  settings, exchange rates) is now scoped by `restaurant_id`. Your existing
  live database migrates automatically on first boot — your current
  restaurant becomes tenant `"default"` and keeps working with its existing
  printed QR codes, admin password, and kitchen PIN.
- **Login**: admin/kitchen now log in with the restaurant's **phone number +
  password**, since the phone number is what identifies which restaurant's
  dashboard to open.
- **Registration**: `/api/restaurants/register` lets a new restaurant sign
  itself up (name, phone, password) and get a 14-day free trial.
- **Owner bot**: a second, private Telegram bot only you can talk to.
  Commands: `/new`, `/list`, `/extend`, `/activate`, `/suspend`. This is how
  you create restaurants and turn their access on/off after they pay you
  (cash, Click, Payme, transfer — however you collect it).
- **QR codes**: now encode which restaurant a table belongs to
  (`?table=5&r=rest-abc123`). Your existing printed QR codes still work
  (they fall back to the `default` tenant) — reprint them from the Admin →
  QR tab once you're on the new version to get the explicit restaurant id.

## New environment variables (add to your `.env` on the server)

```
DEFAULT_TRIAL_DAYS=14
OWNER_API_SECRET=<openssl rand -hex 24>
OWNER_BOT_TOKEN=<from @BotFather — make a NEW bot, separate from your customer verification bot>
OWNER_TELEGRAM_IDS=<your numeric Telegram user id, comma-separated if more than one person>
OWNER_BOT_WEBHOOK_SECRET=<openssl rand -hex 24>
```

To get your numeric Telegram ID, message a bot like @userinfobot.

## Deploying

Same as before — `npm install`, `npm run build`, run `dist/server.cjs` (or
`npm run dev` locally). The database migration runs automatically the first
time the new code starts against your existing `data/restaurant.db`.

**Back up `data/restaurant.db` before deploying this**, as always with any
schema change — though the migration only adds data, it never deletes
anything.

## Using the owner bot day-to-day

1. Message your owner bot `/new +998901234567 Some Restaurant Name`
2. It replies with a login (the phone number) and an auto-generated
   password — send those to the client
3. They log in at `yourdomain.com?view=admin`, add their tables/menu, and
   get their own QR codes to print from the Admin → QR tab
4. When their 14-day trial is up (or whenever they pay you), message
   `/extend +998901234567 30` (or however many days) to keep them active
5. If someone doesn't pay, `/suspend +998901234567` — their app immediately
   stops serving customers/staff until you `/activate` or `/extend` again

## What's still worth doing next

- Per-restaurant branding (logo/colors) if you want to sell this as a
  white-label product rather than everyone seeing "Qulaycafe" styling
- Usage-based pricing tiers (e.g. limit menu items or tables on a free
  trial) if you want to upsell paid plans beyond a flat monthly fee

## Marketing landing page vs. the app, on ONE domain (qulaycafe.uz)

You only have `qulaycafe.uz`, and it needs to do two different jobs:

1. Be a normal marketing site people find via Google/Instagram — for
   people who don't have an account yet.
2. Be the actual ordering app — for restaurant customers scanning a table
   QR, and for restaurant owners/kitchen staff logging in.

Those two audiences must never land on the wrong one. The fix is a
**subdomain**, which is free (just one more DNS record on a domain you
already own):

- `qulaycafe.uz` (and `www.qulaycafe.uz`) → the marketing landing page
  (`landing/index.html` in this repo — already built, in Uzbek, with a
  "Bepul boshlash" call-to-action).
- `app.qulaycafe.uz` → this app, completely unchanged.

### DNS setup (one-time, with whoever you bought the domain from)

Add an **A record** (or CNAME, if your host tells you to use one) for
`app` pointing at the same server your existing `qulaycafe.uz` A record
points at. That's it — no new hosting, no new server.

### How the routing works

`server.ts` checks the incoming request's hostname very early, before any
restaurant/session logic runs:

- If the hostname is `qulaycafe.uz` or `www.qulaycafe.uz` (configurable
  via the `LANDING_HOSTNAMES` env var, comma-separated, if you ever change
  domains), it serves the static files in `landing/` and never touches the
  app at all.
- Every other hostname (i.e. `app.qulaycafe.uz`, or `localhost` while
  developing) falls straight through to the app exactly as before.

You don't need to change any QR codes or links inside the app — they're
already generated from `window.location.origin`, so once customers/owners
reach the app at `app.qulaycafe.uz`, every QR code and shareable link it
generates automatically uses that same subdomain.

**One thing to update once you launch:** point the landing page's
"Bepul boshlash" / "Kirish" buttons (in `landing/index.html`) at
`https://app.qulaycafe.uz` — they're already set to that URL by default,
just update it if you pick a different subdomain name.

