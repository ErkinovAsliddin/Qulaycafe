import 'dotenv/config';
import crypto from 'crypto';
import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import helmet from 'helmet';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import pino from 'pino';
import pinoHttp from 'pino-http';
import { ZodSchema } from 'zod';
import { OAuth2Client } from 'google-auth-library';
import {
  telegramConfigured,
  createVerificationToken,
  getVerificationStatus,
  markVerified,
  sendTelegramMessage,
  registerWebhook,
  verifyTelegramWebAppInitData
} from './src/server/telegram';
import { ownerBotConfigured, registerOwnerWebhook, handleOwnerBotMessage, checkExpiringSubscriptionsAndNotifyOwner } from './src/server/ownerBot';
import {
  deliveryBotConfigured,
  registerDeliveryBotWebhook,
  handleDeliveryBotUpdate,
  notifyCouriersOfNewOrder,
  deliveryEvents
} from './src/server/deliveryBot';
import { buildReceiptBytes, sendToNetworkPrinter } from './src/server/escpos';
import { createServer as createViteServer } from 'vite';
import {
  db,
  backupNow,
  getRestaurantById,
  getRestaurantByPhone,
  getRestaurantBySlug,
  createRestaurant,
  isSubscriptionUsable,
  getSubscription,
  listRestaurantsWithSubscriptions,
  setSubscriptionStatus,
  updateRestaurantBranding,
  setAdminTelegramLink,
  unlinkAdminTelegram,
  createWaiterCall,
  listWaiterCalls,
  resolveWaiterCall,
  setDeliveryStatus,
  createCourier,
  listCouriers,
  setCourierStatus,
  getCourierById,
  upsertDailyClosure,
  getDailyClosure
} from './src/server/db';
import {
  requireRole,
  requireActiveSubscription,
  requireOwner,
  verifyPassword,
  setPassword,
  setSessionCookie,
  clearSessionCookie,
  verifySession,
  isLockedOut,
  recordFailedAttempt,
  clearFailedAttempts
} from './src/server/auth';
import {
  menuItemCreateSchema,
  menuItemUpdateSchema,
  orderCreateSchema,
  orderStatusUpdateSchema,
  tableCreateSchema,
  loyaltyRegisterSchema,
  loginSchema,
  phoneLoginSchema,
  restaurantRegisterSchema,
  ownerCreateRestaurantSchema,
  ownerSubscriptionUpdateSchema,
  changePasswordSchema,
  googleVerifySchema,
  exchangeRateUpdateSchema,
  settingsUpdateSchema,
  brandingUpdateSchema,
  waiterCallSchema,
  printerSettingsSchema,
  courierNameUpdateSchema
} from './src/server/validation';
import bcrypt from 'bcryptjs';
import ExcelJS from 'exceljs';
import { MenuItem, Order, Table, LoyaltyMember, InventoryLog } from './src/types';

const logger = pino({ level: process.env.LOG_LEVEL || 'info' });
const isProd = process.env.NODE_ENV === 'production';

// ---------------------------------------------------------------------------
// Real-time updates via Server-Sent Events, split into two scopes:
//  - Staff stream (admin/kitchen only, session-gated): full order details,
//    inventory, and table state, exactly like a kitchen display needs.
//  - Table-scoped stream (public but narrow): a customer only receives
//    updates for their OWN table's order status and general menu/table
//    availability — never other tables' orders or any loyalty-member data.
// The original build broadcast full orders + the entire loyalty member list
// (names/phones/emails/points) to every connected browser tab, including
// customers. That data exposure is fixed by this split.
// ---------------------------------------------------------------------------
type StaffSSEClient = { res: Response; restaurantId: string };
type TableSSEClient = { res: Response; restaurantId: string; tableNumber?: number };
type OrderSSEClient = { res: Response; restaurantId: string; orderId: string };
const staffClients: StaffSSEClient[] = [];
const tableClients: TableSSEClient[] = [];
const orderClients: OrderSSEClient[] = [];

function sseSend(res: Response, type: string, data: unknown) {
  res.write(`data: ${JSON.stringify({ type, data, timestamp: new Date().toISOString() })}\n\n`);
}

// Every broadcast is scoped to ONE restaurant_id — otherwise restaurant A's
// staff dashboard would see restaurant B's live orders, and vice versa.
function broadcastStaff(restaurantId: string, type: string, data: unknown) {
  staffClients
    .filter(c => c.restaurantId === restaurantId)
    .forEach(c => {
      try {
        sseSend(c.res, type, data);
      } catch (e) {
        logger.error({ err: e }, 'SSE staff send error');
      }
    });
}

function broadcastTable(restaurantId: string, tableNumber: number, type: string, data: unknown) {
  tableClients
    .filter(c => c.restaurantId === restaurantId && c.tableNumber === tableNumber)
    .forEach(c => {
      try {
        sseSend(c.res, type, data);
      } catch (e) {
        logger.error({ err: e }, 'SSE table send error');
      }
    });
}

// Delivery orders don't have a real table (they all share the tableNumber=0
// sentinel), so broadcasting by table number would leak one delivery
// customer's order details (address, phone, items) to every OTHER delivery
// customer of the same restaurant watching that same channel. This scopes
// the update to exactly the one order it belongs to instead.
function broadcastOrder(restaurantId: string, orderId: string, type: string, data: unknown) {
  orderClients
    .filter(c => c.restaurantId === restaurantId && c.orderId === orderId)
    .forEach(c => {
      try {
        sseSend(c.res, type, data);
      } catch (e) {
        logger.error({ err: e }, 'SSE order send error');
      }
    });
}

function broadcastTableAll(restaurantId: string, type: string, data: unknown) {
  tableClients
    .filter(c => c.restaurantId === restaurantId)
    .forEach(c => {
      try {
        sseSend(c.res, type, data);
      } catch (e) {
        logger.error({ err: e }, 'SSE table-all send error');
      }
    });
}

// ---------------------------------------------------------------------------
// Generic request-validation middleware. Every mutating endpoint below runs
// its body through a zod schema before touching the database. Anything that
// doesn't match the schema is rejected with 400 and never reaches business
// logic.
// ---------------------------------------------------------------------------
function validateBody<T extends ZodSchema>(schema: T) {
  return (req: Request, res: Response, next: NextFunction) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      res.status(400).json({ error: 'Invalid request data', details: result.error.flatten() });
      return;
    }
    req.body = result.data;
    next();
  };
}

// --- Data access helpers (SQLite-backed, replacing the old in-memory arrays) --
// Every one of these takes restaurantId and scopes the query to it — this is
// the core of tenant isolation: no query below ever runs without it.
function readMenu(restaurantId: string): MenuItem[] {
  return (
    db.prepare('SELECT data FROM menu_items WHERE restaurant_id = ?').all(restaurantId) as { data: string }[]
  ).map(r => JSON.parse(r.data));
}
function readOrders(restaurantId: string): Order[] {
  return (
    db
      .prepare('SELECT data FROM orders WHERE restaurant_id = ? ORDER BY created_at DESC')
      .all(restaurantId) as { data: string }[]
  ).map(r => JSON.parse(r.data));
}
function readTables(restaurantId: string): Table[] {
  return (
    db
      .prepare('SELECT data FROM tables WHERE restaurant_id = ? ORDER BY table_number ASC')
      .all(restaurantId) as { data: string }[]
  ).map(r => JSON.parse(r.data));
}
function readLoyalty(restaurantId: string): LoyaltyMember[] {
  return (
    db.prepare('SELECT data FROM loyalty_members WHERE restaurant_id = ?').all(restaurantId) as { data: string }[]
  ).map(r => JSON.parse(r.data));
}
function readInventoryLogs(restaurantId: string): InventoryLog[] {
  return (
    db
      .prepare('SELECT data FROM inventory_logs WHERE restaurant_id = ? ORDER BY created_at DESC LIMIT 500')
      .all(restaurantId) as { data: string }[]
  ).map(r => JSON.parse(r.data));
}

// Identifies which restaurant a CUSTOMER request belongs to — customers
// have no session cookie, so this comes from the QR code's URL, forwarded
// by the frontend as either an X-Restaurant-Id header or an ?r= query
// param. Falls back to the "default" tenant (the original single-restaurant
// deployment) so existing printed QR codes keep working without a reprint.
// Blocks the request with a friendly message if the restaurant's
// subscription isn't active — this is the ONLY enforcement point needed for
// "stop working if the owner didn't pay", with no payment gateway involved.
function resolvePublicRestaurantId(req: Request): string {
  const headerVal = req.header('X-Restaurant-Id');
  const queryVal = typeof req.query.r === 'string' ? req.query.r : undefined;
  return (headerVal || queryVal || 'default').trim();
}

function requirePublicRestaurant(req: Request, res: Response, next: NextFunction) {
  const restaurantId = resolvePublicRestaurantId(req);
  const restaurant = getRestaurantById(restaurantId);
  if (!restaurant) {
    res.status(404).json({ error: 'Restoran topilmadi.' });
    return;
  }
  if (!isSubscriptionUsable(restaurantId)) {
    res.status(402).json({
      error: "Bu restoran hozircha ishlamayapti. Iltimos, ma'muriyat bilan bog'laning.",
      code: 'SUBSCRIPTION_INACTIVE'
    });
    return;
  }
  req.restaurantId = restaurantId;
  next();
}

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  // Trust the first proxy hop (needed on Hostinger/AWS behind Nginx/ALB/Cloudflare)
  // so rate limiting and secure cookies see the real client IP/protocol.
  app.set('trust proxy', 1);

  // --- Security headers ---
  app.use(
    helmet({
      contentSecurityPolicy: isProd
        ? {
            directives: {
              defaultSrc: ["'self'"],
              imgSrc: ["'self'", 'data:', 'https:'],
              scriptSrc: ["'self'", 'https://accounts.google.com/gsi/client'],
              styleSrc: ["'self'", "'unsafe-inline'"],
              connectSrc: ["'self'", 'https://accounts.google.com'],
              frameSrc: ["'self'", 'https://accounts.google.com'],
              frameAncestors: ["'none'"]
            }
          }
        : false, // relaxed in dev so Vite HMR keeps working
      // Helmet's default 'same-origin' isolates this page's window from any
      // popup it opens, breaking the postMessage handshake Google Sign-In's
      // popup relies on (this is the exact cause of "Cannot read properties
      // of null (reading 'postMessage')"). 'same-origin-allow-popups' keeps
      // the isolation for framing/Spectre purposes but still lets an opened
      // popup talk back to us.
      crossOriginOpenerPolicy: { policy: 'same-origin-allow-popups' }
    })
  );

  // --- CORS: only allow explicitly configured origins (never "*") ---
  const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(o => o.trim()).filter(Boolean);
  app.use(
    cors({
      origin: (origin, callback) => {
        if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
          callback(null, true);
        } else {
          callback(new Error('Not allowed by CORS'));
        }
      },
      credentials: true
    })
  );

  app.use(cookieParser());
  app.use(express.json({ limit: '8mb' })); // uploaded photos are base64-encoded in the request body
  app.use(express.urlencoded({ limit: '8mb', extended: true }));
  app.use(pinoHttp({ logger, redact: ['req.headers.cookie', 'req.headers.authorization'] }));

  // ---------------------------------------------------------------------
  // Marketing landing page vs. the actual ordering app, on ONE domain.
  // qulaycafe.uz (and www.) — the link put on Google/Instagram/business
  // cards — serves the static marketing landing page. Every other
  // hostname (i.e. app.qulaycafe.uz, where restaurant customers scan a
  // table QR and restaurant owners log in) falls through to the real app
  // below, completely unchanged. This runs before any restaurant/session
  // logic so a landing-page visitor never touches app auth/state at all.
  // Configurable via LANDING_HOSTNAMES (comma-separated) in case the
  // domain ever changes — defaults cover the current qulaycafe.uz setup.
  // ---------------------------------------------------------------------
  const landingHostnames = (process.env.LANDING_HOSTNAMES || 'qulaycafe.uz,www.qulaycafe.uz')
    .split(',')
    .map(h => h.trim().toLowerCase())
    .filter(Boolean);
  const landingPath = path.join(process.cwd(), 'landing');
  if (fs.existsSync(landingPath)) {
    const landingStatic = express.static(landingPath, { extensions: ['html'] });
    app.use((req: Request, res: Response, next: NextFunction) => {
      if (!landingHostnames.includes(req.hostname.toLowerCase())) {
        next();
        return;
      }
      landingStatic(req, res, () => {
        // No matching static asset for this path on the landing domain
        // (e.g. a deep link, or a trailing slash variant) — fall back to
        // the landing page itself rather than ever reaching the app.
        res.sendFile(path.join(landingPath, 'index.html'));
      });
    });
  }

  // --- Rate limiting ---
  app.use(
    '/api/',
    rateLimit({ windowMs: 60_000, limit: 300, standardHeaders: true, legacyHeaders: false })
  );
  const loginLimiter = rateLimit({
    windowMs: 60_000,
    limit: 10,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many login attempts. Please wait a minute and try again.' }
  });
  const orderLimiter = rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false });

  // Staff real-time stream: full detail, admin/kitchen session required.
  // restaurantId comes from the session (req.restaurantId), never from the
  // client, so one restaurant's staff can never subscribe to another's feed.
  app.get('/api/events', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    // Tells Nginx (and similar reverse proxies) not to buffer this response.
    // Without this, notifications can sit in a proxy buffer and only
    // arrive once it flushes — which looks exactly like "I have to
    // refresh to see new orders" even though the server sent them instantly.
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    const client: StaffSSEClient = { res, restaurantId: req.restaurantId as string };
    staffClients.push(client);
    req.on('close', () => {
      const idx = staffClients.indexOf(client);
      if (idx !== -1) staffClients.splice(idx, 1);
    });
  });

  // Customer real-time stream: scoped to one table AND one restaurant, no
  // auth required (a dining guest isn't logged in), but never carries other
  // tables'/restaurants' data.
  app.get('/api/events/table/:tableNumber', requirePublicRestaurant, (req: Request, res: Response) => {
    const tableNumber = Number(req.params.tableNumber);
    if (!Number.isFinite(tableNumber)) {
      res.status(400).end();
      return;
    }
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    const client: TableSSEClient = { res, restaurantId: req.restaurantId as string, tableNumber };
    tableClients.push(client);
    req.on('close', () => {
      const idx = tableClients.indexOf(client);
      if (idx !== -1) tableClients.splice(idx, 1);
    });
  });

  // Delivery orders don't have a table to scope by, and sharing one channel
  // across every delivery customer of a restaurant would leak one
  // customer's address/phone/items to another watching the same stream —
  // this is scoped to exactly one order instead.
  app.get('/api/events/order/:orderId', requirePublicRestaurant, (req: Request, res: Response) => {
    const orderId = req.params.orderId;
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no');
    res.flushHeaders();
    const client: OrderSSEClient = { res, restaurantId: req.restaurantId as string, orderId };
    orderClients.push(client);
    req.on('close', () => {
      const idx = orderClients.indexOf(client);
      if (idx !== -1) orderClients.splice(idx, 1);
    });
  });

  const googleClientId = (process.env.GOOGLE_CLIENT_ID || '').trim().replace(/^["']|["']$/g, '');
  const googleClient = googleClientId ? new OAuth2Client(googleClientId) : null;
  if (googleClientId && !googleClientId.endsWith('.apps.googleusercontent.com')) {
    logger.warn(
      { googleClientId },
      "GOOGLE_CLIENT_ID doesn't look like a real Google OAuth Client ID (should end in .apps.googleusercontent.com) — double-check you copied the Client ID, not the Client Secret, and that there are no stray quotes/spaces in .env"
    );
  }

  // The Client ID is not secret (it's meant to be embedded in frontend JS) —
  // safe to expose here so the frontend doesn't need it hardcoded/rebuilt.
  app.get('/api/auth/google/config', (_req: Request, res: Response) => {
    res.json({ clientId: googleClientId, configured: !!googleClientId });
  });

  // Real verification: the ID token is a signed JWT from Google. We verify
  // its signature, issuer, audience (our Client ID), and expiry server-side
  // via google-auth-library — this cannot be forged by typing an email into
  // a form, unlike the old mocked flow.
  app.post(
    '/api/auth/google/verify',
    orderLimiter,
    validateBody(googleVerifySchema),
    async (req: Request, res: Response) => {
      if (!googleClient || !googleClientId) {
        res.status(503).json({
          error: 'Google Sign-In is not configured on this server yet. Set GOOGLE_CLIENT_ID in .env.'
        });
        return;
      }
      try {
        const ticket = await googleClient.verifyIdToken({
          idToken: req.body.credential,
          audience: googleClientId
        });
        const payload = ticket.getPayload();
        if (!payload || !payload.email) {
          res.status(401).json({ error: 'Invalid Google credential' });
          return;
        }
        res.json({
          id: 'google-' + payload.sub,
          email: payload.email,
          name: payload.name || payload.email.split('@')[0],
          picture: payload.picture || '',
          givenName: payload.given_name || (payload.name || '').split(' ')[0]
        });
      } catch (err: any) {
        req.log.warn(
          { err: err?.message, googleClientId },
          'Google ID token verification failed — check that GOOGLE_CLIENT_ID here matches Google Cloud Console exactly, and that your domain is in Authorized JavaScript origins'
        );
        res.status(401).json({ error: 'Could not verify Google credential' });
      }
    }
  );

  // --- TELEGRAM BOT VERIFICATION ---
  // Real verification: the customer taps "Verify with Telegram", we hand
  // them a one-time deep link to YOUR bot, they press Start there (proving
  // they control that Telegram account), and the bot's webhook marks the
  // token verified. The browser polls for that. This replaces a flow that
  // used to accept a universal bypass code and never verified anything.
  const TELEGRAM_WEBHOOK_SECRET = process.env.TELEGRAM_WEBHOOK_SECRET || '';

  app.get('/api/auth/telegram/config', (_req: Request, res: Response) => {
    res.json({ configured: telegramConfigured });
  });

  app.post('/api/auth/telegram/start', orderLimiter, (_req: Request, res: Response) => {
    if (!telegramConfigured) {
      res.status(503).json({ error: 'Telegram verification is not configured on this server yet.' });
      return;
    }
    const { token, deepLink } = createVerificationToken();
    res.json({ token, deepLink });
  });

  app.get('/api/auth/telegram/status/:token', (req: Request, res: Response) => {
    const status = getVerificationStatus(req.params.token);
    res.json(status);
  });

  // Validates the signed initData a Telegram Mini App launch is handed,
  // proving the person genuinely opened this page from inside Telegram as
  // that specific Telegram account — a legitimate identity-verification
  // path, same trust level as the deep-link bot flow above but instant.
  app.post('/api/auth/telegram/webapp-verify', loginLimiter, (req: Request, res: Response) => {
    const initData = req.body?.initData;
    if (typeof initData !== 'string' || initData.length > 4000) {
      res.status(400).json({ error: 'invalid initData' });
      return;
    }
    const user = verifyTelegramWebAppInitData(initData);
    if (!user) {
      res.status(401).json({ error: 'Could not verify Telegram Mini App identity' });
      return;
    }
    res.json({ verified: true, telegramUserId: user.id, telegramUsername: user.username, telegramFirstName: user.firstName });
  });

  // Telegram calls this endpoint directly when someone messages the bot.
  // The secret_token header (set during setWebhook) proves the request
  // actually came from Telegram and not an attacker hitting this URL
  // directly to fake a verification.
  app.post('/api/telegram/webhook', async (req: Request, res: Response) => {
    if (TELEGRAM_WEBHOOK_SECRET) {
      const incomingSecret = req.header('X-Telegram-Bot-Api-Secret-Token');
      if (incomingSecret !== TELEGRAM_WEBHOOK_SECRET) {
        res.status(401).end();
        return;
      }
    }
    const message = req.body?.message;
    const text: string | undefined = message?.text;
    const from = message?.from;

    if (text && text.startsWith('/start') && from) {
      const parts = text.split(' ');
      const payload = parts[1];

      if (payload && payload.startsWith('order_')) {
        const slug = payload.slice('order_'.length);
        const restaurant = getRestaurantBySlug(slug);
        if (!restaurant) {
          await sendTelegramMessage(from.id, "Bu restoran topilmadi. Havola noto'g'ri bo'lishi mumkin.");
        } else if (!process.env.APP_URL) {
          await sendTelegramMessage(from.id, "Ilova hali to'liq sozlanmagan. Iltimos, veb-saytdan foydalaning.");
        } else {
          await sendTelegramMessage(
            from.id,
            `🍽 <b>${restaurant.name}</b>\n\nMenyu va buyurtma berish uchun quyidagi tugmani bosing.`,
            [{ text: '🛵 Buyurtma berish', web_app: { url: `${process.env.APP_URL.replace(/\/$/, '')}/order/${slug}` } }]
          );
        }
        res.status(200).end();
        return;
      }

      const token = payload;
      if (token) {
        const result = markVerified(token, from);
        if (result.ok && result.purpose === 'admin_notify' && result.restaurantId) {
          setAdminTelegramLink(result.restaurantId, String(from.id), from.username || null);
          await sendTelegramMessage(
            from.id,
            "✅ Ulandi! Endi yangi buyurtma kelganda shu yerga xabar yuboraman."
          );
        } else {
          await sendTelegramMessage(
            from.id,
            result.ok
              ? '✅ Verified! You can return to the browser now — your table is ready to order.'
              : '⚠️ This verification link has expired or was already used. Please request a new one from the website.'
          );
        }
      } else {
        await sendTelegramMessage(from.id, 'Hi! Open this bot from the restaurant website to verify your account.');
      }
    }
    res.status(200).end(); // Telegram just needs a 200; content is ignored
  });

  // --- OWNER BOT WEBHOOK (Alex's private subscription-management bot) ---
  const OWNER_BOT_WEBHOOK_SECRET = process.env.OWNER_BOT_WEBHOOK_SECRET || '';
  app.post('/api/owner-bot/webhook', async (req: Request, res: Response) => {
    if (OWNER_BOT_WEBHOOK_SECRET) {
      const incomingSecret = req.header('X-Telegram-Bot-Api-Secret-Token');
      if (incomingSecret !== OWNER_BOT_WEBHOOK_SECRET) {
        res.status(401).end();
        return;
      }
    }
    await handleOwnerBotMessage(req.body?.message);
    res.status(200).end();
  });

  // --- RESTAURANT SELF-REGISTRATION ---
  // OFF by default. Alex sells this system by hand — a restaurant contacts
  // him, pays, and he creates their login via the owner Telegram bot. Set
  // ENABLE_SELF_REGISTRATION=true in .env if you ever want restaurants to
  // sign themselves up directly instead.
  const selfRegistrationEnabled = process.env.ENABLE_SELF_REGISTRATION === 'true';

  // Lets the frontend know whether to show a "register" form or an
  // "contact the admin" card, without hardcoding it into the built assets.
  // Resolves a restaurant's shareable link (qulaycafe.uz/order/<slug>) to
  // its internal id. Public and deliberately minimal — a slug is not
  // secret (it's meant to be shared on Instagram etc.), so this only
  // returns what's needed to render the ordering page, nothing sensitive.
  app.get('/api/restaurants/by-slug/:slug', (req: Request, res: Response) => {
    const restaurant = getRestaurantBySlug(req.params.slug);
    if (!restaurant) {
      res.status(404).json({ error: 'Restoran topilmadi.' });
      return;
    }
    res.json({ restaurantId: restaurant.id, name: restaurant.name, deliveryStatus: restaurant.delivery_status });
  });

  app.get('/api/registration-info', (_req: Request, res: Response) => {
    res.json({
      selfRegistrationEnabled,
      contactPhone: process.env.OWNER_CONTACT_PHONE || null,
      contactTelegram: process.env.OWNER_CONTACT_TELEGRAM || null
    });
  });

  // App-wide, non-secret config the frontend needs regardless of which
  // restaurant is active — currently just which Telegram bot customers use
  // to open a restaurant's ordering page as a Mini App.
  app.get('/api/app-config', (_req: Request, res: Response) => {
    res.json({ telegramBotUsername: process.env.TELEGRAM_BOT_USERNAME || null });
  });

  app.post(
    '/api/restaurants/register',
    loginLimiter,
    validateBody(restaurantRegisterSchema),
    (req: Request, res: Response) => {
      if (!selfRegistrationEnabled) {
        res.status(403).json({ error: "Ro'yxatdan o'tish yopiq. Administrator bilan bog'laning." });
        return;
      }
      const { name, phone, password, deliveryEnabled } = req.body;
      if (getRestaurantByPhone(phone)) {
        res.status(409).json({ error: 'Bu telefon raqam bilan restoran allaqachon ro\'yxatdan o\'tgan.' });
        return;
      }
      const passwordHash = bcrypt.hashSync(password, 12);
      const restaurant = createRestaurant({ name, phone, passwordHash, deliveryEnabled });
      setSessionCookie(res, 'admin', restaurant.id);
      req.log.info({ restaurantId: restaurant.id, deliveryEnabled: !!deliveryEnabled }, 'restaurant self-registered');
      res.status(201).json({ success: true, restaurantId: restaurant.id, name: restaurant.name, slug: restaurant.slug, deliveryEnabled: !!deliveryEnabled });
    }
  );

  // --- OWNER (SUPER-ADMIN) ENDPOINTS ---
  // Protected by a single shared secret (X-Owner-Secret header), not a
  // session — only the owner bot and Alex himself call these directly.
  app.get('/api/owner/restaurants', requireOwner, (_req: Request, res: Response) => {
    res.json(listRestaurantsWithSubscriptions());
  });

  app.post(
    '/api/owner/restaurants',
    requireOwner,
    validateBody(ownerCreateRestaurantSchema),
    (req: Request, res: Response) => {
      const { name, phone } = req.body;
      if (getRestaurantByPhone(phone)) {
        res.status(409).json({ error: 'Restaurant with this phone already exists' });
        return;
      }
      const password = crypto.randomBytes(6).toString('hex').slice(0, 8);
      const restaurant = createRestaurant({ name, phone, passwordHash: bcrypt.hashSync(password, 12) });
      res.status(201).json({ success: true, restaurant, password });
    }
  );

  app.post(
    '/api/owner/subscription',
    requireOwner,
    validateBody(ownerSubscriptionUpdateSchema),
    (req: Request, res: Response) => {
      const { restaurantId, status, extendDays } = req.body;
      if (!getRestaurantById(restaurantId)) {
        res.status(404).json({ error: 'Restaurant not found' });
        return;
      }
      const periodEnd = extendDays ? new Date(Date.now() + extendDays * 24 * 60 * 60 * 1000).toISOString() : null;
      setSubscriptionStatus(restaurantId, status, periodEnd, 'Updated via owner API');
      res.json({ success: true });
    }
  );

  // --- ADMIN TELEGRAM ORDER NOTIFICATIONS ---
  // Reuses the same bot/token as customer verification, just a different
  // "purpose" on the token so the webhook knows to link a restaurant's
  // admin_telegram_chat_id instead of a customer's loyalty identity.
  app.post('/api/admin/telegram/link-token', requireRole('admin'), (req: Request, res: Response) => {
    if (!telegramConfigured) {
      res.status(503).json({ error: 'Telegram is not configured on this server yet.' });
      return;
    }
    const { token, deepLink } = createVerificationToken({ purpose: 'admin_notify', restaurantId: req.restaurantId });
    res.json({ token, deepLink });
  });

  app.get('/api/admin/telegram/link-status/:token', requireRole('admin'), (req: Request, res: Response) => {
    res.json(getVerificationStatus(req.params.token));
  });

  app.post('/api/admin/telegram/unlink', requireRole('admin'), (req: Request, res: Response) => {
    unlinkAdminTelegram(req.restaurantId as string);
    res.json({ success: true });
  });

  // --- WAITER CALLS ---
  app.post(
    '/api/waiter-call',
    requirePublicRestaurant,
    orderLimiter,
    validateBody(waiterCallSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const call = createWaiterCall(restaurantId, req.body.tableNumber);
      broadcastStaff(restaurantId, 'WAITER_CALL', call);
      res.status(201).json(call);
    }
  );

  app.get('/api/admin/waiter-calls', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    const onlyPending = req.query.pending === 'true';
    res.json(listWaiterCalls(req.restaurantId as string, onlyPending));
  });

  app.post('/api/admin/waiter-calls/:id/resolve', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const resolved = resolveWaiterCall(restaurantId, req.params.id);
    if (!resolved) {
      res.status(404).json({ error: 'Call not found' });
      return;
    }
    broadcastStaff(restaurantId, 'WAITER_CALL_RESOLVED', { id: req.params.id });
    res.json({ success: true });
  });
  // The admin always works in so'm — these rates only power an optional
  // "show me this in USD/RUB" conversion for customers. Nothing about the
  // actual amount charged/recorded changes based on this.
  // --- DELIVERY BOT WEBHOOK ---
  const DELIVERY_BOT_WEBHOOK_SECRET = process.env.DELIVERY_BOT_WEBHOOK_SECRET || '';
  app.post('/api/delivery-bot/webhook', async (req: Request, res: Response) => {
    if (DELIVERY_BOT_WEBHOOK_SECRET) {
      const incomingSecret = req.header('X-Telegram-Bot-Api-Secret-Token');
      if (incomingSecret !== DELIVERY_BOT_WEBHOOK_SECRET) {
        res.status(401).end();
        return;
      }
    }
    await handleDeliveryBotUpdate(req.body);
    res.status(200).end();
  });

  // --- COURIER MANAGEMENT (delivery) ---
  app.post('/api/admin/couriers/link-token', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const restaurant = getRestaurantById(restaurantId);
    if (!restaurant || restaurant.delivery_status !== 'active') {
      res.status(403).json({ error: "Dostavka xizmati yoqilmagan." });
      return;
    }
    if (!deliveryBotConfigured) {
      res.status(503).json({ error: 'Delivery bot is not configured on this server yet.' });
      return;
    }
    const { token, deepLink } = createVerificationToken({ purpose: 'courier_link', restaurantId });
    // The delivery bot has its own username, separate from the customer bot
    const botUsername = process.env.TELEGRAM_DELIVERY_BOT_USERNAME || '';
    res.json({ token, deepLink: botUsername ? `https://t.me/${botUsername}?start=${token}` : deepLink });
  });

  app.get('/api/admin/couriers', requireRole('admin'), (req: Request, res: Response) => {
    res.json(listCouriers(req.restaurantId as string));
  });

  app.post('/api/admin/couriers/:id/toggle', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const courier = getCourierById(restaurantId, req.params.id);
    if (!courier) {
      res.status(404).json({ error: 'Courier not found' });
      return;
    }
    setCourierStatus(restaurantId, courier.id, courier.status === 'active' ? 'inactive' : 'active');
    res.json({ success: true });
  });

  // --- THERMAL PRINTER (ESC/POS over network, port 9100 style) ---
  app.get('/api/admin/printer-settings', requireRole('admin'), (req: Request, res: Response) => {
    const s = readSettings(req.restaurantId as string) as any;
    const rows = db
      .prepare(`SELECT key, value FROM settings WHERE restaurant_id = ? AND key IN ('printerIp','printerPort')`)
      .all(req.restaurantId) as { key: string; value: string }[];
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    res.json({ printerIp: map.printerIp || '', printerPort: Number(map.printerPort) || 9100 });
  });

  app.post(
    '/api/admin/printer-settings',
    requireRole('admin'),
    validateBody(printerSettingsSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { printerIp, printerPort } = req.body;
      if (printerIp !== undefined) {
        db.prepare(
          `INSERT INTO settings (restaurant_id, key, value) VALUES (?, 'printerIp', ?) ON CONFLICT(restaurant_id, key) DO UPDATE SET value = ?`
        ).run(restaurantId, printerIp, printerIp);
      }
      if (printerPort !== undefined) {
        db.prepare(
          `INSERT INTO settings (restaurant_id, key, value) VALUES (?, 'printerPort', ?) ON CONFLICT(restaurant_id, key) DO UPDATE SET value = ?`
        ).run(restaurantId, String(printerPort), String(printerPort));
      }
      res.json({ success: true });
    }
  );

  app.post('/api/admin/print-receipt/:orderId', requireRole('admin'), async (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const row = db
      .prepare('SELECT data FROM orders WHERE restaurant_id = ? AND id = ?')
      .get(restaurantId, req.params.orderId) as { data: string } | undefined;
    if (!row) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    const printerRow = db
      .prepare(`SELECT key, value FROM settings WHERE restaurant_id = ? AND key IN ('printerIp','printerPort')`)
      .all(restaurantId) as { key: string; value: string }[];
    const map: Record<string, string> = {};
    for (const r of printerRow) map[r.key] = r.value;
    if (!map.printerIp) {
      res.status(400).json({ error: "Printer IP manzili sozlanmagan. Avval Sozlamalar bo'limida kiriting." });
      return;
    }
    const restaurant = getRestaurantById(restaurantId);
    try {
      const bytes = buildReceiptBytes(JSON.parse(row.data), restaurant?.name || 'Restoran');
      await sendToNetworkPrinter(map.printerIp, Number(map.printerPort) || 9100, bytes);
      res.json({ success: true });
    } catch (err: any) {
      res.status(502).json({ error: `Printerga ulanib bo'lmadi: ${err?.message || 'unknown error'}` });
    }
  });

  // --- Z-REPORT (daily cash reconciliation) ---
  function computeDailyTotals(restaurantId: string, dateStr: string) {
    const orders = readOrders(restaurantId).filter(
      o => o.createdAt.slice(0, 10) === dateStr && o.status !== 'cancelled'
    );
    const cashTotal = orders
      .filter(o => o.paymentMethod === 'cash' || o.paymentMethod === 'pay_at_counter')
      .reduce((s, o) => s + o.totalAmount, 0);
    const cardTotal = orders.filter(o => o.paymentMethod === 'card').reduce((s, o) => s + o.totalAmount, 0);
    const otherTotal = orders
      .filter(o => o.paymentMethod === 'loyalty_points')
      .reduce((s, o) => s + o.totalAmount, 0);
    return { cashTotal, cardTotal, otherTotal, orderCount: orders.length, totalRevenue: cashTotal + cardTotal + otherTotal };
  }

  app.get('/api/admin/z-report', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const dateStr = (req.query.date as string) || new Date().toISOString().slice(0, 10);
    const totals = computeDailyTotals(restaurantId, dateStr);
    const closure = getDailyClosure(restaurantId, dateStr);
    res.json({ date: dateStr, ...totals, closure: closure || null });
  });

  app.post('/api/admin/z-report/close', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const dateStr = (req.body?.date as string) || new Date().toISOString().slice(0, 10);
    const totals = computeDailyTotals(restaurantId, dateStr);
    upsertDailyClosure(
      restaurantId,
      dateStr,
      { cashTotal: totals.cashTotal, cardTotal: totals.cardTotal, otherTotal: totals.otherTotal, orderCount: totals.orderCount },
      req.body?.note
    );
    res.json({ success: true, date: dateStr, ...totals });
  });

  // --- EXCHANGE RATES (for customer-facing currency display only) ---
  function readExchangeRates(restaurantId: string): Record<string, { rateToSom: number; updatedAt: string; source: string }> {
    const rows = db
      .prepare('SELECT currency, rate_to_som, updated_at, source FROM exchange_rates WHERE restaurant_id = ?')
      .all(restaurantId) as {
      currency: string;
      rate_to_som: number;
      updated_at: string;
      source: string;
    }[];
    const result: Record<string, { rateToSom: number; updatedAt: string; source: string }> = {};
    for (const row of rows) {
      result[row.currency] = { rateToSom: row.rate_to_som, updatedAt: row.updated_at, source: row.source };
    }
    return result;
  }

  // --- RESTAURANT SETTINGS (tax % and service fee %, admin-editable) ---
  function readSettings(restaurantId: string): { taxPercent: number; serviceFeePercent: number } {
    const rows = db.prepare('SELECT key, value FROM settings WHERE restaurant_id = ?').all(restaurantId) as {
      key: string;
      value: string;
    }[];
    const map: Record<string, string> = {};
    for (const r of rows) map[r.key] = r.value;
    return {
      taxPercent: Number(map.taxPercent ?? 8),
      serviceFeePercent: Number(map.serviceFeePercent ?? 5)
    };
  }

  app.get('/api/settings', requirePublicRestaurant, (req: Request, res: Response) => {
    const restaurant = getRestaurantById(req.restaurantId as string);
    const contactRows = db
      .prepare(`SELECT key, value FROM settings WHERE restaurant_id = ? AND key IN ('contactPhone','contactAddress','contactInstagram','workingHours')`)
      .all(req.restaurantId) as { key: string; value: string }[];
    const contactMap: Record<string, string> = {};
    for (const r of contactRows) contactMap[r.key] = r.value;
    res.json({
      ...readSettings(req.restaurantId as string),
      restaurantName: restaurant?.name || null,
      logoUrl: restaurant?.logo_url || null,
      brandColor: restaurant?.brand_color || null,
      contactPhone: contactMap.contactPhone || null,
      contactAddress: contactMap.contactAddress || null,
      contactInstagram: contactMap.contactInstagram || null,
      workingHours: contactMap.workingHours || null,
      deliveryStatus: restaurant?.delivery_status || 'disabled'
    });
  });

  // --- BRANDING (logo, accent color, display name, contact info) ---
  app.post(
    '/api/admin/branding',
    requireRole('admin'),
    requireActiveSubscription,
    validateBody(brandingUpdateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { logoUrl, brandColor, displayName, contactPhone, contactAddress, contactInstagram, workingHours } = req.body;
      updateRestaurantBranding(restaurantId, { logoUrl: logoUrl === '' ? null : logoUrl, brandColor, displayName });

      const contactFields: Record<string, string | undefined> = { contactPhone, contactAddress, contactInstagram, workingHours };
      for (const [key, value] of Object.entries(contactFields)) {
        if (value === undefined) continue;
        db.prepare(
          `INSERT INTO settings (restaurant_id, key, value) VALUES (?, ?, ?) ON CONFLICT(restaurant_id, key) DO UPDATE SET value = ?`
        ).run(restaurantId, key, value, value);
      }

      const restaurant = getRestaurantById(restaurantId);
      const settingsRows = db
        .prepare(`SELECT key, value FROM settings WHERE restaurant_id = ? AND key IN ('contactPhone','contactAddress','contactInstagram','workingHours')`)
        .all(restaurantId) as { key: string; value: string }[];
      const map: Record<string, string> = {};
      for (const r of settingsRows) map[r.key] = r.value;

      const updated = {
        restaurantName: restaurant?.name || null,
        logoUrl: restaurant?.logo_url || null,
        brandColor: restaurant?.brand_color || null,
        contactPhone: map.contactPhone || null,
        contactAddress: map.contactAddress || null,
        contactInstagram: map.contactInstagram || null,
        workingHours: map.workingHours || null
      };
      broadcastTableAll(restaurantId, 'BRANDING_UPDATED', updated);
      res.json({ success: true, ...updated });
    }
  );

  app.post(
    '/api/admin/settings',
    requireRole('admin'),
    requireActiveSubscription,
    validateBody(settingsUpdateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { taxPercent, serviceFeePercent } = req.body;
      if (taxPercent !== undefined) {
        db.prepare(
          `INSERT INTO settings (restaurant_id, key, value) VALUES (?, 'taxPercent', ?) ON CONFLICT(restaurant_id, key) DO UPDATE SET value = ?`
        ).run(restaurantId, String(taxPercent), String(taxPercent));
      }
      if (serviceFeePercent !== undefined) {
        db.prepare(
          `INSERT INTO settings (restaurant_id, key, value) VALUES (?, 'serviceFeePercent', ?) ON CONFLICT(restaurant_id, key) DO UPDATE SET value = ?`
        ).run(restaurantId, String(serviceFeePercent), String(serviceFeePercent));
      }
      const updated = readSettings(restaurantId);
      broadcastTableAll(restaurantId, 'SETTINGS_UPDATED', updated);
      broadcastStaff(restaurantId, 'SETTINGS_UPDATED', updated);
      res.json({ success: true, ...updated });
    }
  );

  app.get('/api/exchange-rates', requirePublicRestaurant, (req: Request, res: Response) => {
    res.json(readExchangeRates(req.restaurantId as string));
  });

  app.post(
    '/api/admin/exchange-rates',
    requireRole('admin'),
    requireActiveSubscription,
    validateBody(exchangeRateUpdateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { currency, rateToSom } = req.body;
      db.prepare(
        `INSERT INTO exchange_rates (restaurant_id, currency, rate_to_som, updated_at, source) VALUES (?, ?, ?, ?, 'manual')
         ON CONFLICT(restaurant_id, currency) DO UPDATE SET rate_to_som = ?, updated_at = ?, source = 'manual'`
      ).run(restaurantId, currency, rateToSom, new Date().toISOString(), rateToSom, new Date().toISOString());
      broadcastTableAll(restaurantId, 'EXCHANGE_RATES_UPDATED', readExchangeRates(restaurantId));
      res.json({ success: true, rates: readExchangeRates(restaurantId) });
    }
  );

  // Best-effort daily auto-refresh from a free public rate API, applied to
  // EVERY restaurant tenant. If this fails for any reason (no internet
  // egress, API down, etc.) the existing rates just stay as they are — this
  // never blocks or breaks anything.
  async function refreshExchangeRatesFromLiveSource() {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8000);
      const res = await fetch('https://open.er-api.com/v6/latest/USD', { signal: controller.signal });
      clearTimeout(timeout);
      if (!res.ok) return;
      const data: any = await res.json();
      const usdToUzs = data?.rates?.UZS;
      const usdToRub = data?.rates?.RUB;
      if (typeof usdToUzs !== 'number' || usdToUzs <= 0) return;

      const now = new Date().toISOString();
      const rubToUzs = typeof usdToRub === 'number' && usdToRub > 0 ? usdToUzs / usdToRub : null;
      const restaurantIds = (db.prepare('SELECT id FROM restaurants').all() as { id: string }[]).map(r => r.id);

      for (const restaurantId of restaurantIds) {
        db.prepare(
          `INSERT INTO exchange_rates (restaurant_id, currency, rate_to_som, updated_at, source) VALUES (?, 'USD', ?, ?, 'auto')
           ON CONFLICT(restaurant_id, currency) DO UPDATE SET rate_to_som = ?, updated_at = ?, source = 'auto'`
        ).run(restaurantId, usdToUzs, now, usdToUzs, now);

        if (rubToUzs) {
          db.prepare(
            `INSERT INTO exchange_rates (restaurant_id, currency, rate_to_som, updated_at, source) VALUES (?, 'RUB', ?, ?, 'auto')
             ON CONFLICT(restaurant_id, currency) DO UPDATE SET rate_to_som = ?, updated_at = ?, source = 'auto'`
          ).run(restaurantId, rubToUzs, now, rubToUzs, now);
        }
        broadcastTableAll(restaurantId, 'EXCHANGE_RATES_UPDATED', readExchangeRates(restaurantId));
      }
      logger.info({ usdToUzs, usdToRub, restaurantCount: restaurantIds.length }, 'exchange rates auto-refreshed');
    } catch (err) {
      logger.warn({ err }, 'exchange rate auto-refresh failed — keeping existing rates');
    }
  }

  app.get('/api/health', (_req: Request, res: Response) => {
    try {
      db.prepare('SELECT 1').get();
      res.json({ status: 'ok', timestamp: new Date().toISOString() });
    } catch {
      res.status(503).json({ status: 'error', error: 'database unavailable' });
    }
  });

  // --- AUTH ENDPOINTS (real, server-side, hashed) ---
  // Staff now log in with their RESTAURANT'S phone number + password/PIN —
  // the phone number is what identifies which restaurant's dashboard they
  // land in. Lockout tracking is per (restaurant, role), so a bad-actor
  // hammering one restaurant's login never locks out another restaurant.
  app.post('/api/auth/admin/login', loginLimiter, validateBody(phoneLoginSchema), (req: Request, res: Response) => {
    const { phone, password } = req.body;
    const restaurant = getRestaurantByPhone(phone);
    if (!restaurant) {
      res.status(401).json({ error: 'Telefon raqam yoki parol xato' });
      return;
    }
    const lockout = isLockedOut(restaurant.id, 'admin');
    if (lockout.locked) {
      res.status(429).json({ error: 'Ko\'p urinish. Biroz kutib qayta urinib ko\'ring.', retryAfterSeconds: lockout.retryAfterSeconds });
      return;
    }
    if (!verifyPassword(restaurant.id, 'admin', password)) {
      recordFailedAttempt(restaurant.id, 'admin');
      res.status(401).json({ error: 'Telefon raqam yoki parol xato' });
      return;
    }
    // Password is correct, but a suspended/expired subscription blocks
    // login ENTIRELY — this is the real enforcement point for "if the
    // owner hasn't paid, the whole restaurant stops working", not just
    // specific write endpoints.
    if (!isSubscriptionUsable(restaurant.id)) {
      const sub = getSubscription(restaurant.id);
      res.status(402).json({
        error:
          sub?.status === 'suspended'
            ? "Obunangiz to'xtatilgan. Davom etish uchun administrator bilan bog'laning."
            : "Obunangiz muddati tugagan. Davom etish uchun administrator bilan bog'laning.",
        code: 'SUBSCRIPTION_INACTIVE'
      });
      return;
    }
    clearFailedAttempts(restaurant.id, 'admin');
    setSessionCookie(res, 'admin', restaurant.id);
    res.json({ success: true, restaurantId: restaurant.id, restaurantName: restaurant.name, subscriptionPeriodEnd: getSubscription(restaurant.id)?.current_period_end || null, deliveryStatus: restaurant.delivery_status });
  });

  app.post('/api/auth/kitchen/login', loginLimiter, validateBody(phoneLoginSchema), (req: Request, res: Response) => {
    const { phone, password } = req.body;
    const restaurant = getRestaurantByPhone(phone);
    if (!restaurant) {
      res.status(401).json({ error: 'Telefon raqam yoki PIN xato' });
      return;
    }
    const lockout = isLockedOut(restaurant.id, 'kitchen');
    if (lockout.locked) {
      res.status(429).json({ error: 'Ko\'p urinish. Biroz kutib qayta urinib ko\'ring.', retryAfterSeconds: lockout.retryAfterSeconds });
      return;
    }
    if (!verifyPassword(restaurant.id, 'kitchen', password) && !verifyPassword(restaurant.id, 'admin', password)) {
      recordFailedAttempt(restaurant.id, 'kitchen');
      res.status(401).json({ error: 'Telefon raqam yoki PIN xato' });
      return;
    }
    if (!isSubscriptionUsable(restaurant.id)) {
      const sub = getSubscription(restaurant.id);
      res.status(402).json({
        error:
          sub?.status === 'suspended'
            ? "Obunangiz to'xtatilgan. Davom etish uchun administrator bilan bog'laning."
            : "Obunangiz muddati tugagan. Davom etish uchun administrator bilan bog'laning.",
        code: 'SUBSCRIPTION_INACTIVE'
      });
      return;
    }
    clearFailedAttempts(restaurant.id, 'kitchen');
    setSessionCookie(res, 'kitchen', restaurant.id);
    res.json({ success: true, restaurantId: restaurant.id, restaurantName: restaurant.name, subscriptionPeriodEnd: getSubscription(restaurant.id)?.current_period_end || null, deliveryStatus: restaurant.delivery_status });
  });

  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    clearSessionCookie(res);
    res.json({ success: true });
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const token = req.cookies?.session;
    if (!token) {
      res.json({ role: null });
      return;
    }
    const payload = verifySession(token);
    if (!payload) {
      res.json({ role: null });
      return;
    }
    const restaurant = getRestaurantById(payload.restaurantId);
    const subscriptionOk = isSubscriptionUsable(payload.restaurantId);
    const subscription = getSubscription(payload.restaurantId);
    res.json({
      role: payload.role,
      restaurantId: payload.restaurantId,
      restaurantName: restaurant?.name || null,
      restaurantSlug: restaurant?.slug || null,
      subscriptionActive: subscriptionOk,
      subscriptionPeriodEnd: subscription?.current_period_end || null,
      deliveryStatus: restaurant?.delivery_status || 'disabled'
    });
  });

  // Changing the password requires an active, valid admin session cookie
  // (requireRole('admin')) — that's the identity proof. Scoped to the
  // logged-in restaurant only.
  app.post(
    '/api/auth/admin/change-password',
    requireRole('admin'),
    validateBody(changePasswordSchema),
    (req: Request, res: Response) => {
      setPassword(req.restaurantId as string, 'admin', req.body.newPassword);
      res.json({ success: true });
    }
  );

  app.post(
    '/api/auth/kitchen/change-pin',
    requireRole('admin'),
    validateBody(changePasswordSchema),
    (req: Request, res: Response) => {
      setPassword(req.restaurantId as string, 'kitchen', req.body.newPassword);
      res.json({ success: true });
    }
  );

  // --- MENU ENDPOINTS (reads public, writes admin-only) ---
  app.get('/api/menu', requirePublicRestaurant, (req: Request, res: Response) => {
    res.json(readMenu(req.restaurantId as string));
  });

  app.post(
    '/api/menu',
    requireRole('admin'),
    requireActiveSubscription,
    validateBody(menuItemCreateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const body = req.body;
      const newItem: MenuItem = {
        id: 'm-' + Date.now() + '-' + crypto.randomBytes(3).toString('hex'),
        name: body.nameUz, // canonical field — kitchen/orders/receipts always show Uzbek
        description: body.descriptionUz,
        nameUz: body.nameUz,
        nameRu: body.nameRu,
        nameEn: body.nameEn,
        descriptionUz: body.descriptionUz,
        descriptionRu: body.descriptionRu,
        descriptionEn: body.descriptionEn,
        price: body.price,
        category: body.category,
        image: body.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
        stock: body.stock,
        isAvailable: body.stock > 0,
        dietary: body.dietary,
        prepTimeMinutes: body.prepTimeMinutes,
        customizations: body.customizations
      };
      db.prepare('INSERT INTO menu_items (restaurant_id, id, data) VALUES (?, ?, ?)').run(
        restaurantId,
        newItem.id,
        JSON.stringify(newItem)
      );
      req.log.info({ menuItemId: newItem.id }, 'menu item created');
      broadcastTableAll(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));
      broadcastStaff(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));
      res.status(201).json(newItem);
    }
  );

  app.put(
    '/api/menu/:id',
    requireRole('admin'),
    requireActiveSubscription,
    validateBody(menuItemUpdateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { id } = req.params;
      const row = db.prepare('SELECT data FROM menu_items WHERE restaurant_id = ? AND id = ?').get(restaurantId, id) as
        | { data: string }
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'Item not found' });
        return;
      }
      const existing: MenuItem = JSON.parse(row.data);
      const previousStock = existing.stock;
      const patch = { ...req.body };
      if (patch.image === '') delete patch.image; // empty string means "no change", not "clear the photo"
      const updated: MenuItem = { ...existing, ...patch, id: existing.id };
      // Keep the canonical name/description (used by kitchen/orders/receipts)
      // in sync whenever the Uzbek fields are edited.
      if (patch.nameUz !== undefined) updated.name = patch.nameUz;
      if (patch.descriptionUz !== undefined) updated.description = patch.descriptionUz;
      if (updated.stock <= 0) updated.isAvailable = false;

      db.prepare('UPDATE menu_items SET data = ? WHERE restaurant_id = ? AND id = ?').run(
        JSON.stringify(updated),
        restaurantId,
        id
      );

      if (req.body.stock !== undefined && req.body.stock !== previousStock) {
        const change = req.body.stock - previousStock;
        const log: InventoryLog = {
          id: 'log-' + Date.now() + '-' + crypto.randomBytes(3).toString('hex'),
          menuItemId: id,
          menuItemName: updated.name,
          changeAmount: change,
          newStock: updated.stock,
          reason: req.body.stockReason || (change > 0 ? 'restock' : 'manual_adjustment'),
          timestamp: new Date().toISOString()
        };
        db.prepare('INSERT INTO inventory_logs (restaurant_id, id, data, created_at) VALUES (?, ?, ?, ?)').run(
          restaurantId,
          log.id,
          JSON.stringify(log),
          log.timestamp
        );
      }

      broadcastTableAll(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));
      broadcastStaff(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));
      res.json(updated);
    }
  );

  app.delete('/api/menu/:id', requireRole('admin'), requireActiveSubscription, (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const { id } = req.params;
    db.prepare('DELETE FROM menu_items WHERE restaurant_id = ? AND id = ?').run(restaurantId, id);
    broadcastTableAll(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));
    broadcastStaff(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));
    res.json({ success: true, id });
  });

  // --- ORDERS ENDPOINTS ---
  app.get('/api/orders', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    res.json(readOrders(req.restaurantId as string));
  });

  // Customers can only fetch orders for their own table, not the whole list.
  app.get('/api/orders/table/:tableNumber', requirePublicRestaurant, (req: Request, res: Response) => {
    const tableNumber = Number(req.params.tableNumber);
    if (!Number.isFinite(tableNumber)) {
      res.status(400).json({ error: 'Invalid table number' });
      return;
    }
    res.json(readOrders(req.restaurantId as string).filter(o => o.tableNumber === tableNumber));
  });

  app.post(
    '/api/orders',
    requirePublicRestaurant,
    orderLimiter,
    validateBody(orderCreateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const idempotencyKey = req.header('Idempotency-Key');

      if (idempotencyKey) {
        const existing = db
          .prepare('SELECT order_id FROM idempotency_keys WHERE key = ? AND restaurant_id = ?')
          .get(idempotencyKey, restaurantId) as { order_id: string } | undefined;
        if (existing) {
          const row = db
            .prepare('SELECT data FROM orders WHERE restaurant_id = ? AND id = ?')
            .get(restaurantId, existing.order_id) as { data: string } | undefined;
          if (row) {
            res.status(200).json(JSON.parse(row.data));
            return;
          }
        }
      }

      const {
        tableNumber,
        customerName,
        customerPhoneOrEmail,
        items,
        subtotal,
        discount,
        loyaltyPointsRedeemed,
        paymentMethod,
        orderNote,
        orderType,
        deliveryAddress,
        deliveryPhone,
        deliveryLat,
        deliveryLng
      } = req.body;

      // Pickup ("olib ketish") never touches the courier fleet, so it
      // doesn't need the delivery service to be active for this restaurant
      // — only real courier-delivered orders are gated on that.
      if (orderType === 'delivery') {
        const restaurant = getRestaurantById(restaurantId);
        if (!restaurant || restaurant.delivery_status !== 'active') {
          res.status(403).json({ error: "Dostavka xizmati ushbu restoran uchun yoqilmagan." });
          return;
        }
      }

      // Server-side recompute/sanity-check against authoritative menu prices,
      // instead of trusting client-submitted totals outright.
      const menu = readMenu(restaurantId);
      let recomputedSubtotal = 0;
      for (const cartItem of items) {
        const menuItem = menu.find(m => m.id === cartItem.menuItem.id);
        if (!menuItem) {
          res.status(400).json({ error: `Menu item ${cartItem.menuItem.id} does not exist` });
          return;
        }
        if (!menuItem.isAvailable || menuItem.stock < cartItem.quantity) {
          res.status(409).json({ error: `${menuItem.name} is not available in the requested quantity` });
          return;
        }
        recomputedSubtotal += cartItem.itemTotal;
      }
      if (Math.abs(recomputedSubtotal - subtotal) > 0.5) {
        res.status(400).json({ error: 'Order total does not match menu pricing' });
        return;
      }

      // Tax and service charge are ALWAYS computed here from the current
      // settings, never trusted from the client — otherwise a customer could
      // tamper with these values in the request to pay less. The discount
      // (from loyalty points) is also capped server-side at 50% of subtotal,
      // matching the same rule the cart UI uses.
      const { taxPercent, serviceFeePercent } = readSettings(restaurantId);
      const authoritativeTax = Math.round((recomputedSubtotal * taxPercent) / 100);
      const authoritativeServiceCharge = Math.round((recomputedSubtotal * serviceFeePercent) / 100);
      const requestedDiscount = Math.max(0, Number(discount) || 0);
      const maxDiscount = recomputedSubtotal * 0.5;
      const authoritativeDiscount = Math.min(requestedDiscount, maxDiscount);
      const authoritativeTotal = Math.max(
        0,
        recomputedSubtotal + authoritativeTax + authoritativeServiceCharge - authoritativeDiscount
      );

      const orderId = 'ORD-' + Date.now().toString(36).toUpperCase() + '-' + Math.floor(100 + Math.random() * 900);
      // Loyalty economics, calibrated for so'm-scale totals: earn 1 point per
      // 1,000 so'm spent, each point worth 100 so'm when redeemed (~10% back).
      const pointsEarned = Math.round(authoritativeTotal / 1000);

      const newOrder: Order = {
        id: orderId,
        tableNumber: Number(tableNumber),
        customerName:
          customerName ||
          (orderType === 'delivery'
            ? 'Dostavka mijozi'
            : orderType === 'pickup'
            ? 'Olib ketish mijozi'
            : `Table ${tableNumber} Guest`),
        customerPhoneOrEmail: customerPhoneOrEmail || '',
        items,
        subtotal: recomputedSubtotal,
        tax: authoritativeTax,
        serviceCharge: authoritativeServiceCharge,
        discount: authoritativeDiscount,
        totalAmount: authoritativeTotal,
        status: 'pending',
        paymentStatus: paymentMethod === 'card' ? 'paid' : 'unpaid',
        paymentMethod: paymentMethod || 'cash',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        estimatedMinutes: 15,
        loyaltyPointsEarned: pointsEarned,
        loyaltyPointsRedeemed: Number(loyaltyPointsRedeemed) || 0,
        orderNote,
        orderType: orderType || 'dine_in',
        deliveryAddress: orderType === 'delivery' ? deliveryAddress : undefined,
        // Pickup orders still carry a contact phone (reusing the same
        // field) so the kitchen/admin can call the customer when their
        // order is ready — they just never get an address or courier.
        deliveryPhone: orderType === 'delivery' || orderType === 'pickup' ? deliveryPhone : undefined,
        deliveryLat: orderType === 'delivery' && typeof deliveryLat === 'number' ? deliveryLat : undefined,
        deliveryLng: orderType === 'delivery' && typeof deliveryLng === 'number' ? deliveryLng : undefined
      };

      const tx = db.transaction(() => {
        db.prepare('INSERT INTO orders (restaurant_id, id, table_number, data, created_at) VALUES (?, ?, ?, ?, ?)').run(
          restaurantId,
          newOrder.id,
          newOrder.tableNumber,
          JSON.stringify(newOrder),
          newOrder.createdAt
        );

        if (idempotencyKey) {
          db.prepare('INSERT INTO idempotency_keys (key, order_id, restaurant_id, created_at) VALUES (?, ?, ?, ?)').run(
            idempotencyKey,
            newOrder.id,
            restaurantId,
            new Date().toISOString()
          );
        }

        for (const cartItem of items) {
          const row = db
            .prepare('SELECT data FROM menu_items WHERE restaurant_id = ? AND id = ?')
            .get(restaurantId, cartItem.menuItem.id) as { data: string } | undefined;
          if (!row) continue;
          const menuItem: MenuItem = JSON.parse(row.data);
          const newStock = Math.max(0, menuItem.stock - cartItem.quantity);
          menuItem.stock = newStock;
          if (newStock === 0) menuItem.isAvailable = false;
          db.prepare('UPDATE menu_items SET data = ? WHERE restaurant_id = ? AND id = ?').run(
            JSON.stringify(menuItem),
            restaurantId,
            menuItem.id
          );

          const log: InventoryLog = {
            id: 'log-' + Date.now() + '-' + Math.random().toString(36).slice(2, 7),
            menuItemId: menuItem.id,
            menuItemName: menuItem.name,
            changeAmount: -cartItem.quantity,
            newStock,
            reason: 'customer_order',
            timestamp: new Date().toISOString()
          };
          db.prepare('INSERT INTO inventory_logs (restaurant_id, id, data, created_at) VALUES (?, ?, ?, ?)').run(
            restaurantId,
            log.id,
            JSON.stringify(log),
            log.timestamp
          );
        }

        const tableRow = db
          .prepare('SELECT data FROM tables WHERE restaurant_id = ? AND table_number = ?')
          .get(restaurantId, Number(tableNumber)) as { data: string } | undefined;
        if (tableRow) {
          const t: Table = JSON.parse(tableRow.data);
          t.status = 'eating';
          t.currentOrderId = orderId;
          t.activeItemsCount = items.length;
          db.prepare('UPDATE tables SET data = ? WHERE restaurant_id = ? AND table_number = ?').run(
            JSON.stringify(t),
            restaurantId,
            t.tableNumber
          );
        }

        if (customerPhoneOrEmail) {
          const loyaltyRow = db
            .prepare('SELECT id, data FROM loyalty_members WHERE restaurant_id = ? AND phone_or_email = ?')
            .get(restaurantId, String(customerPhoneOrEmail).toLowerCase()) as
            | { id: string; data: string }
            | undefined;
          if (loyaltyRow) {
            const member: LoyaltyMember = JSON.parse(loyaltyRow.data);
            member.pointsBalance += pointsEarned - (Number(loyaltyPointsRedeemed) || 0);
            member.totalSpent += authoritativeTotal;
            member.ordersCount += 1;
            if (member.totalSpent > 500) member.tier = 'Platinum';
            else if (member.totalSpent > 200) member.tier = 'Gold';
            db.prepare('UPDATE loyalty_members SET data = ? WHERE restaurant_id = ? AND id = ?').run(
              JSON.stringify(member),
              restaurantId,
              member.id
            );
          }
        }
      });
      tx();

      req.log.info({ orderId, tableNumber, restaurantId }, 'order created');
      broadcastStaff(restaurantId, 'ORDER_CREATED', { order: newOrder });
      broadcastTable(restaurantId, Number(tableNumber), 'ORDER_CREATED', { order: newOrder });
      broadcastOrder(restaurantId, newOrder.id, 'ORDER_CREATED', { order: newOrder });
      broadcastTableAll(restaurantId, 'MENU_UPDATED', readMenu(restaurantId));

      // Best-effort — if the admin hasn't linked their Telegram, or the
      // message fails to send, the order itself is already saved and the
      // dashboard/SSE stream still shows it live.
      const owningRestaurant = getRestaurantById(restaurantId);
      if (owningRestaurant?.admin_telegram_chat_id) {
        const itemsSummary = items
          .map((ci: { menuItem: { name: string }; quantity: number }) => `${ci.quantity}x ${ci.menuItem.name}`)
          .join(', ');
        const adminMessage =
          orderType === 'delivery'
            ? `🛵 Yangi DOSTAVKA buyurtmasi\n${itemsSummary}\nJami: ${authoritativeTotal.toLocaleString('uz-UZ')} so'm`
            : orderType === 'pickup'
            ? `🥡 Yangi OLIB KETISH buyurtmasi\n${itemsSummary}\nJami: ${authoritativeTotal.toLocaleString('uz-UZ')} so'm\nMijoz tayyor bo'lganda o'zi keladi.`
            : `🔔 Yangi buyurtma — Stol #${tableNumber}\n${itemsSummary}\nJami: ${authoritativeTotal.toLocaleString('uz-UZ')} so'm`;
        sendTelegramMessage(owningRestaurant.admin_telegram_chat_id, adminMessage).catch(() => {});
      }

      // Only real courier-delivered orders page the courier fleet — pickup
      // orders are picked up by the customer themselves, so the kitchen
      // just prepares them like any other ticket and no courier is ever
      // notified.
      if (orderType === 'delivery') {
        notifyCouriersOfNewOrder(restaurantId, newOrder).catch(err => {
          logger.warn({ err, orderId }, 'failed to notify couriers of new delivery order');
        });
      }

      res.status(201).json(newOrder);
    }
  );

  app.patch(
    '/api/orders/:id/status',
    requireRole('admin', 'kitchen'),
    validateBody(orderStatusUpdateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { id } = req.params;
      const { status, paymentStatus } = req.body;

      const row = db.prepare('SELECT data FROM orders WHERE restaurant_id = ? AND id = ?').get(restaurantId, id) as
        | { data: string }
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'Order not found' });
        return;
      }
      const order: Order = JSON.parse(row.data);
      if (status) order.status = status;
      if (paymentStatus) order.paymentStatus = paymentStatus;
      order.updatedAt = new Date().toISOString();

      db.prepare('UPDATE orders SET data = ? WHERE restaurant_id = ? AND id = ?').run(
        JSON.stringify(order),
        restaurantId,
        id
      );

      if (status === 'paid') {
        const tableRow = db
          .prepare('SELECT data FROM tables WHERE restaurant_id = ? AND table_number = ?')
          .get(restaurantId, order.tableNumber) as { data: string } | undefined;
        if (tableRow) {
          const t: Table = JSON.parse(tableRow.data);
          t.status = 'available';
          t.currentOrderId = undefined;
          t.activeItemsCount = 0;
          db.prepare('UPDATE tables SET data = ? WHERE restaurant_id = ? AND table_number = ?').run(
            JSON.stringify(t),
            restaurantId,
            t.tableNumber
          );
          broadcastStaff(restaurantId, 'TABLES_UPDATED', readTables(restaurantId));
        }
      }

      broadcastStaff(restaurantId, 'ORDER_UPDATED', { order });
      broadcastTable(restaurantId, order.tableNumber, 'ORDER_UPDATED', { order });
      broadcastOrder(restaurantId, order.id, 'ORDER_UPDATED', { order });
      res.json(order);
    }
  );

  // --- LOYALTY ENDPOINTS ---
  app.get('/api/loyalty', requireRole('admin', 'kitchen'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const query = String(req.query.q || '').toLowerCase().trim();
    if (!query) {
      res.json(readLoyalty(restaurantId));
      return;
    }
    const member = readLoyalty(restaurantId).find(
      l => l.phoneOrEmail.toLowerCase() === query || l.name.toLowerCase().includes(query)
    );
    res.json(member || null);
  });

  // Public, narrow: a customer can look up ONLY their own record by exact
  // phone/email match — never a general search, never the full list.
  app.get('/api/loyalty/lookup', requirePublicRestaurant, orderLimiter, (req: Request, res: Response) => {
    const identifier = String(req.query.identifier || '').toLowerCase().trim();
    if (!identifier) {
      res.status(400).json({ error: 'identifier is required' });
      return;
    }
    const row = db
      .prepare('SELECT data FROM loyalty_members WHERE restaurant_id = ? AND phone_or_email = ?')
      .get(req.restaurantId, identifier) as { data: string } | undefined;
    res.json(row ? JSON.parse(row.data) : null);
  });

  app.post(
    '/api/loyalty',
    requirePublicRestaurant,
    orderLimiter,
    validateBody(loyaltyRegisterSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { name, phoneOrEmail, confirmationCode } = req.body;
      const key = String(phoneOrEmail).toLowerCase();
      const existingRow = db
        .prepare('SELECT data FROM loyalty_members WHERE restaurant_id = ? AND phone_or_email = ?')
        .get(restaurantId, key) as { data: string } | undefined;
      if (existingRow) {
        res.json(JSON.parse(existingRow.data));
        return;
      }
      const newMember: LoyaltyMember = {
        id: 'loy-' + Date.now() + '-' + crypto.randomBytes(3).toString('hex'),
        name,
        phoneOrEmail,
        confirmationCode: confirmationCode || Math.floor(1000 + Math.random() * 9000).toString(),
        pointsBalance: 100,
        tier: 'Silver',
        totalSpent: 0,
        ordersCount: 0,
        joinedDate: new Date().toISOString().split('T')[0]
      };
      db.prepare('INSERT INTO loyalty_members (restaurant_id, id, phone_or_email, data) VALUES (?, ?, ?, ?)').run(
        restaurantId,
        newMember.id,
        key,
        JSON.stringify(newMember)
      );
      res.status(201).json(newMember);
    }
  );

  // --- TABLES ENDPOINTS ---
  app.get('/api/tables', requirePublicRestaurant, (req: Request, res: Response) => {
    res.json(readTables(req.restaurantId as string));
  });

  app.post(
    '/api/tables',
    requireRole('admin'),
    requireActiveSubscription,
    validateBody(tableCreateSchema),
    (req: Request, res: Response) => {
      const restaurantId = req.restaurantId as string;
      const { tableNumber, capacity, comment } = req.body;
      const existing = db
        .prepare('SELECT data FROM tables WHERE restaurant_id = ? AND table_number = ?')
        .get(restaurantId, tableNumber) as { data: string } | undefined;
      if (existing) {
        const t: Table = JSON.parse(existing.data);
        t.capacity = capacity;
        t.comment = comment ?? t.comment ?? '';
        db.prepare('UPDATE tables SET data = ? WHERE restaurant_id = ? AND table_number = ?').run(
          JSON.stringify(t),
          restaurantId,
          tableNumber
        );
        broadcastStaff(restaurantId, 'TABLES_UPDATED', readTables(restaurantId));
        broadcastTableAll(restaurantId, 'TABLE_INFO_UPDATED', { tableNumber, comment: t.comment });
        res.json(t);
        return;
      }
      const newTable: Table = { tableNumber, capacity, status: 'available', activeItemsCount: 0, comment: comment || '' };
      db.prepare('INSERT INTO tables (restaurant_id, table_number, data) VALUES (?, ?, ?)').run(
        restaurantId,
        tableNumber,
        JSON.stringify(newTable)
      );
      broadcastStaff(restaurantId, 'TABLES_UPDATED', readTables(restaurantId));
      res.status(201).json(newTable);
    }
  );

  app.delete('/api/tables/:tableNumber', requireRole('admin'), requireActiveSubscription, (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const tableNum = Number(req.params.tableNumber);
    db.prepare('DELETE FROM tables WHERE restaurant_id = ? AND table_number = ?').run(restaurantId, tableNum);
    broadcastStaff(restaurantId, 'TABLES_UPDATED', readTables(restaurantId));
    res.json({ success: true, tableNumber: tableNum });
  });

  app.get('/api/inventory-logs', requireRole('admin'), (req: Request, res: Response) => {
    res.json(readInventoryLogs(req.restaurantId as string));
  });

  // --- ANALYTICS ---
  // Computed in JS (not SQL aggregates), since each order's line items live
  // inside its JSON `data` blob rather than a separate rows-per-item table.
  // Fine at restaurant scale (hundreds to low thousands of orders) — this
  // is a per-tenant read scoped to one restaurant's own order history.
  app.get('/api/admin/analytics', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const rangeDays = Math.min(Math.max(Number(req.query.days) || 7, 1), 90);
    const cutoff = Date.now() - rangeDays * 24 * 60 * 60 * 1000;
    const previousCutoff = Date.now() - rangeDays * 2 * 24 * 60 * 60 * 1000;

    const allOrders = readOrders(restaurantId).filter(o => o.status !== 'cancelled');
    const orders = allOrders.filter(o => new Date(o.createdAt).getTime() >= cutoff);
    const previousPeriodOrders = allOrders.filter(o => {
      const t = new Date(o.createdAt).getTime();
      return t >= previousCutoff && t < cutoff;
    });

    const revenueByDay: Record<string, number> = {};
    const dishCounts: Record<string, { name: string; quantity: number; revenue: number }> = {};
    const categoryRevenue: Record<string, number> = {};
    const paymentTotals: Record<string, { count: number; revenue: number }> = {
      cash: { count: 0, revenue: 0 },
      card: { count: 0, revenue: 0 },
      loyalty_points: { count: 0, revenue: 0 }
    };
    let deliveryCount = 0;
    let pickupCount = 0;
    let dineInCount = 0;
    let totalRevenue = 0;

    for (const order of orders) {
      const day = order.createdAt.slice(0, 10); // YYYY-MM-DD
      revenueByDay[day] = (revenueByDay[day] || 0) + order.totalAmount;
      totalRevenue += order.totalAmount;

      const method = order.paymentMethod === 'pay_at_counter' ? 'cash' : order.paymentMethod || 'cash';
      if (!paymentTotals[method]) paymentTotals[method] = { count: 0, revenue: 0 };
      paymentTotals[method].count += 1;
      paymentTotals[method].revenue += order.totalAmount;

      if (order.orderType === 'delivery') deliveryCount += 1;
      else if (order.orderType === 'pickup') pickupCount += 1;
      else dineInCount += 1;

      for (const item of order.items) {
        const key = item.menuItem.id;
        if (!dishCounts[key]) dishCounts[key] = { name: item.menuItem.name, quantity: 0, revenue: 0 };
        dishCounts[key].quantity += item.quantity;
        dishCounts[key].revenue += item.itemTotal;

        const category = item.menuItem.category || 'boshqa';
        categoryRevenue[category] = (categoryRevenue[category] || 0) + item.itemTotal;
      }
    }

    const topDishes = Object.values(dishCounts)
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 10);

    const revenueTimeline = Object.entries(revenueByDay)
      .sort(([a], [b]) => (a < b ? -1 : 1))
      .map(([date, revenue]) => ({ date, revenue }));

    const categoryBreakdown = Object.entries(categoryRevenue)
      .sort(([, a], [, b]) => b - a)
      .map(([category, revenue]) => ({ category, revenue }));

    const paymentMethodBreakdown = Object.entries(paymentTotals)
      .filter(([, v]) => v.count > 0)
      .map(([method, v]) => ({ method, ...v }));

    const previousRevenue = previousPeriodOrders.reduce((s, o) => s + o.totalAmount, 0);
    const revenueChangePercent =
      previousRevenue > 0 ? Math.round(((totalRevenue - previousRevenue) / previousRevenue) * 100) : null;

    res.json({
      rangeDays,
      totalRevenue,
      totalOrders: orders.length,
      averageOrderValue: orders.length > 0 ? Math.round(totalRevenue / orders.length) : 0,
      revenueChangePercent,
      previousPeriodRevenue: previousRevenue,
      revenueTimeline,
      topDishes,
      categoryBreakdown,
      paymentMethodBreakdown,
      orderTypeBreakdown: { dineIn: dineInCount, delivery: deliveryCount, pickup: pickupCount }
    });
  });

  // --- EXCEL EXPORT ---
  app.get('/api/admin/orders/export', requireRole('admin'), async (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const restaurant = getRestaurantById(restaurantId);
    const orders = readOrders(restaurantId);

    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Qulaycafe';
    const sheet = workbook.addWorksheet('Buyurtmalar');

    sheet.columns = [
      { header: 'Sana', key: 'date', width: 20 },
      { header: 'Buyurtma ID', key: 'id', width: 22 },
      { header: 'Stol', key: 'table', width: 8 },
      { header: 'Mijoz', key: 'customer', width: 20 },
      { header: 'Taomlar', key: 'items', width: 50 },
      { header: 'Oraliq summa', key: 'subtotal', width: 14 },
      { header: 'Soliq', key: 'tax', width: 12 },
      { header: 'Xizmat haqi', key: 'service', width: 12 },
      { header: 'Chegirma', key: 'discount', width: 12 },
      { header: 'Jami', key: 'total', width: 14 },
      { header: "To'lov usuli", key: 'paymentMethod', width: 16 },
      { header: 'Holati', key: 'status', width: 14 }
    ];
    sheet.getRow(1).font = { bold: true };

    for (const order of orders) {
      sheet.addRow({
        date: new Date(order.createdAt).toLocaleString('uz-UZ'),
        id: order.id,
        table: order.tableNumber,
        customer: order.customerName,
        items: order.items.map(i => `${i.quantity}x ${i.menuItem.name}`).join(', '),
        subtotal: order.subtotal,
        tax: order.tax,
        service: order.serviceCharge,
        discount: order.discount,
        total: order.totalAmount,
        paymentMethod: order.paymentMethod,
        status: order.status
      });
    }

    const filename = `${(restaurant?.name || 'restoran').replace(/[^a-zA-Z0-9]/g, '_')}-buyurtmalar.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    await workbook.xlsx.write(res);
    res.end();
  });

  app.delete('/api/orders/:id', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const { id } = req.params;
    const result = db.prepare('DELETE FROM orders WHERE restaurant_id = ? AND id = ?').run(restaurantId, id);
    if (result.changes === 0) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    req.log.info({ orderId: id }, 'order deleted by admin');
    broadcastStaff(restaurantId, 'ORDER_DELETED', { id });
    res.json({ success: true, id });
  });

  // Data retention: deletes orders (and related stale rows) older than N
  // days, scoped to ONE restaurant so one tenant's cleanup never touches
  // another's data. Runs automatically once a day for every restaurant (see
  // runInitialCleanup below) and can also be triggered on demand from the
  // admin dashboard.
  function runRetentionCleanup(restaurantId: string, olderThanDays: number) {
    const cutoff = new Date(Date.now() - olderThanDays * 24 * 60 * 60 * 1000).toISOString();
    const ordersDeleted = db
      .prepare('DELETE FROM orders WHERE restaurant_id = ? AND created_at < ?')
      .run(restaurantId, cutoff).changes;
    const logsDeleted = db
      .prepare('DELETE FROM inventory_logs WHERE restaurant_id = ? AND created_at < ?')
      .run(restaurantId, cutoff).changes;
    const idempotencyDeleted = db
      .prepare('DELETE FROM idempotency_keys WHERE restaurant_id = ? AND created_at < ?')
      .run(restaurantId, cutoff).changes;
    return { ordersDeleted, logsDeleted, idempotencyDeleted, cutoff };
  }

  app.post('/api/admin/orders/cleanup', requireRole('admin'), (req: Request, res: Response) => {
    const restaurantId = req.restaurantId as string;
    const days = Number(req.body?.olderThanDays) || 30;
    if (days < 1 || days > 3650) {
      res.status(400).json({ error: 'olderThanDays must be between 1 and 3650' });
      return;
    }
    const result = runRetentionCleanup(restaurantId, days);
    req.log.info(result, 'manual retention cleanup run');
    broadcastStaff(restaurantId, 'ORDERS_CLEANED_UP', result);
    res.json({ success: true, ...result });
  });

  app.post('/api/admin/backup', requireRole('admin'), (_req: Request, res: Response) => {
    const backupPath = backupNow();
    res.json({ success: true, path: backupPath });
  });

  // --- Static assets / SPA serving ---
  if (isProd) {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(
      express.static(distPath, {
        setHeaders: (res, filePath) => {
          if (filePath.endsWith('index.html')) {
            res.setHeader('Cache-Control', 'no-cache');
          } else {
            res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
          }
        }
      })
    );
    app.use((req: Request, res: Response, next: NextFunction) => {
      if (req.path.startsWith('/api/')) {
        next(); // let Express's default handler return a proper 404 JSON-less response for a mistyped/missing API route
        return;
      }
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  }

  // --- Centralized error handler: never leak stack traces to the client ---
  app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
    req.log?.error({ err }, 'unhandled error');
    if (res.headersSent) return;
    res.status(500).json({ error: 'Internal server error' });
  });

  app.listen(PORT, '0.0.0.0', () => {
    logger.info(`Restaurant QR System listening on http://localhost:${PORT} (env=${process.env.NODE_ENV || 'development'})`);
  });

  // Automatic data retention: keeps the last N days of orders by default
  // (30, configurable via ORDER_RETENTION_DAYS) so the database doesn't
  // grow forever with tickets nobody needs anymore, run separately for
  // EVERY restaurant tenant. Admin can also trigger this manually (for
  // their own restaurant only) from the dashboard.
  const retentionDays = Number(process.env.ORDER_RETENTION_DAYS) || 30;
  const runInitialCleanup = () => {
    try {
      const restaurantIds = (db.prepare('SELECT id FROM restaurants').all() as { id: string }[]).map(r => r.id);
      for (const restaurantId of restaurantIds) {
        const result = runRetentionCleanup(restaurantId, retentionDays);
        if (result.ordersDeleted > 0) {
          logger.info({ restaurantId, ...result }, 'automatic retention cleanup ran');
        }
      }
    } catch (err) {
      logger.error({ err }, 'automatic retention cleanup failed');
    }
  };
  runInitialCleanup();
  setInterval(runInitialCleanup, 24 * 60 * 60 * 1000);

  refreshExchangeRatesFromLiveSource();
  setInterval(refreshExchangeRatesFromLiveSource, 24 * 60 * 60 * 1000);

  checkExpiringSubscriptionsAndNotifyOwner();
  setInterval(checkExpiringSubscriptionsAndNotifyOwner, 24 * 60 * 60 * 1000);

  if (telegramConfigured && process.env.APP_URL) {
    registerWebhook(process.env.APP_URL, TELEGRAM_WEBHOOK_SECRET);
    logger.info('Telegram webhook registration attempted');
  } else if (telegramConfigured) {
    logger.warn('TELEGRAM_BOT_TOKEN is set but APP_URL is missing — webhook was not registered');
  }

  if (ownerBotConfigured && process.env.APP_URL) {
    registerOwnerWebhook(process.env.APP_URL, OWNER_BOT_WEBHOOK_SECRET);
    logger.info('Owner bot webhook registration attempted');
  } else if (ownerBotConfigured) {
    logger.warn('OWNER_BOT_TOKEN is set but APP_URL is missing — owner bot webhook was not registered');
  }

  if (deliveryBotConfigured && process.env.APP_URL) {
    registerDeliveryBotWebhook(process.env.APP_URL, DELIVERY_BOT_WEBHOOK_SECRET);
    logger.info('Delivery bot webhook registration attempted');
  } else if (deliveryBotConfigured) {
    logger.warn('TELEGRAM_DELIVERY_BOT_TOKEN is set but APP_URL is missing — delivery bot webhook was not registered');
  }

  // A courier accepting/updating a delivery order happens entirely inside
  // Telegram (button taps), not through an HTTP request from the admin's
  // browser — this forwards those changes onto the normal SSE broadcast so
  // the admin dashboard still updates live without a page refresh.
  deliveryEvents.on('orderUpdated', (restaurantId: string, order: Order) => {
    broadcastStaff(restaurantId, 'ORDER_UPDATED', { order });
    broadcastOrder(restaurantId, order.id, 'ORDER_UPDATED', { order });
  });
}

startServer().catch(err => {
  logger.error(err, 'Fatal startup error');
  process.exit(1);
});
